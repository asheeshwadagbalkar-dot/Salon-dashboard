export interface LeadFormData {
  fullName: string;
  whatsappNumber: string;
  salonName: string;
  city: string;
  salonType: string;
  staffCount: string;
  challenge: string;
  consent: boolean;
  honeypot?: string;
}

export interface LeadSubmissionResponse {
  success: boolean;
  isDuplicate?: boolean;
  leadId?: string;
  message?: string;
  error?: string;
  lead?: {
    id: string;
    fullName: string;
    salonName: string;
    city: string;
  };
}

export interface ConfigData {
  whatsappNumber: string;
  brandName: string;
  supportEmail: string;
  demoSlotsToday: number;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface FeatureModule {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  details: string[];
  integrationNote?: string;
  iconName: string;
}
