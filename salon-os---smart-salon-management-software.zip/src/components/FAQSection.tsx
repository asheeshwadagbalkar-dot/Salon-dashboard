import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { FAQItem } from '../types';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      question: 'Kya Salon OS beauty parlour aur unisex salon ke liye hai?',
      answer:
        'Haan, bilkul! Salon OS specifically Indian beauty parlours, hair salons, unisex salons, nail studios, spas aur multi-branch salon chains ke liye design kiya gaya hai. Chahe aapke paas 2 chairs hon ya 15+ chairs, software aapke scale ke anusaar set ho jata hai.',
    },
    {
      question: 'Kya appointment aur billing ek jagah manage kar sakte hain?',
      answer:
        'Haan. Appointment calendar aur POS billing seamlessly integrated hain. Jab client ki service complete hoti hai, reception par 1 click mein appointment checkout ho jati hai aur GST ya Non-GST bill generate ho jata hai with on-screen UPI QR code.',
    },
    {
      question: 'Kya customer records maintain ho sakte hain?',
      answer:
        'Haan. Har customer ka complete digital CRM profile ban jata hai jisme unka phone number, pichli visits ki dates, karwaye gaye treatments, chemical formula notes (jaise hair dye shade ya allergy note), package balance aur lifetime spend record rehta hai.',
    },
    {
      question: 'Kya staff aur inventory management available hai?',
      answer:
        'Haan. Staff attendance, duty shifts, service-wise commission tracking aur individual staff login permissions available hain. Sath hi backbar chemical consumption (shampoo, developer, colors) aur retail product shelf stock tracking with low-stock alerts bhi milta hai.',
    },
    {
      question: 'Kya demo free hai?',
      answer:
        'Haan, demo 100% free hai aur isme koi obligation ya credit card requirement nahi hai. Hamare specialist aapko live screen share par salon ka complete workflow dikhayenge aur aapke salon ke hisab se questions answer karenge.',
    },
    {
      question: 'Setup aur pricing kaise pata chalegi?',
      answer:
        'Free demo call ke dauraan hamari team aapke salon ke size, staff count aur number of branches ke hisab se exact transparent pricing plans aur quick onboarding steps explain karegi.',
    },
    {
      question: 'Kya WhatsApp features ke liye additional integration required hai?',
      answer:
        'Haan. WhatsApp automated messages (jaise booking confirmation, 2-hour appointment reminder aur digital invoice link) ke liye official WhatsApp Business API integration setup zaroori hota hai. Hamari onboarding team is process ko aapke liye guide aur configure karti hai.',
    },
  ];

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faqs" className="py-16 md:py-24 bg-[#090F21] border-b border-slate-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-xs uppercase tracking-wider font-semibold text-[#38BDF8] mb-2 flex items-center justify-center gap-1.5">
            <HelpCircle className="w-4 h-4" />
            <span>Frequently Asked Questions</span>
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Salon Owners Ke Aksar Puche Jane Wale Sawal
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Salon OS ke features, working aur setup se jude transparent answers.
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-slate-900/80 border border-slate-800 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 text-slate-100 hover:text-white transition-colors cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-balance">
                    {faq.question}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-white bg-slate-700' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 font-normal">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
