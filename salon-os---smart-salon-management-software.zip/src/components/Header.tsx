import React from 'react';
import { trackMetaPixelEvent } from '../utils/analytics';

interface HeaderProps {
  onBookDemoClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onBookDemoClick }) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B132B]/90 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          className="text-xl sm:text-2xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <span>Salon</span>
          <span className="text-[#EC4899]">OS</span>
        </a>

        {/* Zone 2: 4-5 clean single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-300">
          <a
            href="#problems"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            Challenges
          </a>
          <a
            href="#features"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            Features
          </a>
          <a
            href="#video-demo"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            Video Demo
          </a>
          <a
            href="#before-after"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            Before vs After
          </a>
          <a
            href="#faqs"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            FAQs
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => {
              trackMetaPixelEvent('ViewContent', { content_name: 'Header Demo CTA' });
              onBookDemoClick();
            }}
            className="px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-[#D946EF] to-[#E11D48] hover:from-[#C026D3] hover:to-[#BE123C] rounded-lg shadow-sm transition-all duration-150 transform active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Book Free Demo
          </button>
        </div>
      </div>
    </header>
  );
};
