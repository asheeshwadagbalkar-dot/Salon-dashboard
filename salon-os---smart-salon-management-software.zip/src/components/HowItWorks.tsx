import React from 'react';
import { FormInput, MonitorPlay, Settings2, ArrowRight } from 'lucide-react';
import { trackMetaPixelEvent } from '../utils/analytics';

interface HowItWorksProps {
  onScheduleDemoClick: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onScheduleDemoClick }) => {
  const steps = [
    {
      number: '01',
      icon: FormInput,
      title: 'Free demo request karein',
      description: 'Neeche diye gaye form mein apna naam, WhatsApp number aur salon details share karein. It takes only 30 seconds.',
    },
    {
      number: '02',
      icon: MonitorPlay,
      title: 'Team se dashboard walkthrough dekhein',
      description: 'Hamari specialist team aapse 1-on-1 Google Meet ya WhatsApp call par live salon software ka demonstration karegi.',
    },
    {
      number: '03',
      icon: Settings2,
      title: 'Apne salon ke workflows aur setup options discuss karein',
      description: 'Aapke chairs, service rate card, staff commission tiers aur printer setup ke hisab se exact onboarding samjhein.',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 bg-[#090F21] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-wider font-semibold text-[#D946EF] mb-2">
            Simple 3-Step Process
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Kaise Shuru Karein? Bilkul Aasan Hai.
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Koi credit card ya advance commitment nahi. Pehle system dekhiye aur samajhiye.
          </p>
        </div>

        {/* 3 Step Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="relative rounded-2xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-mono text-3xl font-extrabold text-[#EC4899]">
                      {step.number}
                    </span>
                    <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-[#38BDF8] group-hover:scale-105 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-white mb-3">
                    {step.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="mt-12 text-center">
          <button
            onClick={() => {
              trackMetaPixelEvent('ViewContent', { content_name: 'How It Works CTA' });
              onScheduleDemoClick();
            }}
            className="px-8 py-4 text-base font-bold text-white bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#F43F5E] hover:from-[#C026D3] hover:to-[#BE123C] rounded-xl shadow-lg shadow-pink-900/30 transition-all duration-150 transform hover:-translate-y-0.5 cursor-pointer inline-flex items-center gap-2"
          >
            <span>Schedule My Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
