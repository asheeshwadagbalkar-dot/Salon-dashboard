import React from 'react';
import { MessageCircle } from 'lucide-react';
import { buildWhatsAppLink, trackMetaPixelEvent } from '../utils/analytics';

interface WhatsAppStickyCTAProps {
  whatsappNumber: string;
}

export const WhatsAppStickyCTA: React.FC<WhatsAppStickyCTAProps> = ({ whatsappNumber }) => {
  const handleClick = () => {
    trackMetaPixelEvent('Contact', { channel: 'whatsapp_sticky_button' });
  };

  const whatsappUrl = buildWhatsAppLink(whatsappNumber);

  return (
    <>
      {/* Mobile Sticky Bottom Bar - Strictly capped below 15% mobile viewport height (height ~ 54px) */}
      <div className="fixed bottom-0 left-0 right-0 z-50 p-2.5 bg-[#0B132B]/95 backdrop-blur-md border-t border-slate-800 md:hidden flex items-center justify-center">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={handleClick}
          className="w-full h-11 px-4 text-xs font-bold text-white bg-[#25D366] hover:bg-[#20BD5A] active:scale-[0.98] rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-black/40 transition-all cursor-pointer truncate"
        >
          <MessageCircle className="w-4 h-4 fill-current shrink-0" />
          <span className="truncate">WhatsApp Par Free Demo Book Karein</span>
        </a>
      </div>

      {/* Desktop Floating Pill at Bottom-Right */}
      <div className="fixed bottom-6 right-6 z-40 hidden md:block">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={handleClick}
          className="group px-4 py-3 bg-[#25D366] hover:bg-[#20BD5A] text-white rounded-2xl shadow-xl shadow-green-950/40 border border-emerald-400/30 flex items-center gap-2.5 transition-all duration-200 transform hover:-translate-y-1 active:translate-y-0 cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <MessageCircle className="w-5 h-5 fill-current" />
          </div>
          <div className="text-left">
            <span className="block text-[10px] uppercase tracking-wider text-green-100 font-semibold leading-none">
              Live Indian Support
            </span>
            <span className="text-xs font-bold whitespace-nowrap">
              WhatsApp Demo Enquiry
            </span>
          </div>
        </a>
      </div>
    </>
  );
};
