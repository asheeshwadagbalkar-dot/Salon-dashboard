import React, { useState } from 'react';
import { Play, Calendar, Receipt, MessageCircle, Clock, CheckCircle2, User, Sparkles } from 'lucide-react';
import { trackMetaPixelEvent } from '../utils/analytics';

interface HeroProps {
  onBookDemoClick: () => void;
  onWatchDemoClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBookDemoClick, onWatchDemoClick }) => {
  const [activeTab, setActiveTab] = useState<'calendar' | 'billing' | 'whatsapp'>('calendar');

  const handlePrimaryClick = () => {
    trackMetaPixelEvent('ViewContent', { content_name: 'Hero Primary CTA' });
    onBookDemoClick();
  };

  const handleSecondaryClick = () => {
    trackMetaPixelEvent('ViewContent', { content_name: 'Hero Secondary CTA' });
    onWatchDemoClick();
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 border-b border-slate-800/60 bg-[#0B132B]">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-b from-[#D946EF]/10 via-[#06B6D4]/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-6 space-y-6 text-left">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#EC4899] bg-[#EC4899]/10 px-3 py-1 rounded-md border border-[#EC4899]/20">
              <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
              <span>ATTENTION SALON OWNERS!</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-[1.15] text-balance">
              Salon Ka Hisab-Kitab, Booking Aur Customers —{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D946EF] via-[#F43F5E] to-[#38BDF8]">
                Ab Sab Ek Dashboard Par!
              </span>
            </h1>

            {/* Subheadline */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
              Appointments, POS Billing, Staff Management, Customer CRM, Inventory, Reports aur WhatsApp Automation ko ek hi smart software se manage karein.
            </p>

            {/* CTA Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2">
              <button
                onClick={handlePrimaryClick}
                className="px-6 py-3.5 text-base font-bold text-white bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#F43F5E] hover:from-[#C026D3] hover:to-[#BE123C] rounded-xl shadow-lg shadow-pink-900/30 transition-all duration-150 transform hover:-translate-y-0.5 active:translate-y-0 text-center cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Book Your FREE Demo</span>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded font-mono">15 Min</span>
              </button>

              <button
                onClick={handleSecondaryClick}
                className="px-5 py-3.5 text-base font-semibold text-slate-200 bg-slate-800/80 hover:bg-slate-800 hover:text-white border border-slate-700/80 rounded-xl transition-colors text-center cursor-pointer flex items-center justify-center gap-2 group"
              >
                <Play className="w-4 h-4 text-[#38BDF8] group-hover:scale-110 transition-transform" />
                <span>Watch Dashboard Demo</span>
              </button>
            </div>

            {/* Trust Note - Compliant with anti-slop: clean, unboxed, strictly verified facts */}
            <div className="pt-2 text-xs sm:text-sm text-slate-400 flex flex-wrap items-center gap-2">
              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-4 h-4" /> 100% Free Live Walkthrough
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>No obligation</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Tailored for Indian Beauty & Unisex Salons</span>
            </div>
          </div>

          {/* Right Column: Interactive Realistic Salon OS Dashboard Mockup */}
          <div className="lg:col-span-6">
            <div className="relative rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-700/60 shadow-2xl shadow-black/80 overflow-hidden">
              
              {/* Top window frame bar */}
              <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                  <span className="text-xs font-medium text-slate-400 ml-2">
                    Salon OS Dashboard — Live Preview
                  </span>
                </div>
                
                {/* Mode switcher tabs */}
                <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-lg border border-slate-800 text-xs">
                  <button
                    onClick={() => setActiveTab('calendar')}
                    className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                      activeTab === 'calendar'
                        ? 'bg-[#D946EF] text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Calendar
                  </button>
                  <button
                    onClick={() => setActiveTab('billing')}
                    className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                      activeTab === 'billing'
                        ? 'bg-[#D946EF] text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    POS Bill
                  </button>
                  <button
                    onClick={() => setActiveTab('whatsapp')}
                    className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                      activeTab === 'whatsapp'
                        ? 'bg-[#D946EF] text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    WhatsApp
                  </button>
                </div>
              </div>

              {/* Real Indian Salon Header metrics strip */}
              <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-slate-900/40">
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
                  <div>
                    <div className="text-white font-bold text-sm sm:text-base flex items-center gap-2">
                      <span>Glamour Unisex Salon & Spa</span>
                      <span className="text-[11px] font-normal text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                        Open Now
                      </span>
                    </div>
                    <p className="text-slate-400 text-xs">Andheri West, Mumbai · 4 Stylists on Duty</p>
                  </div>

                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <span className="text-slate-400 text-[11px] block">Today's Sales</span>
                      <span className="font-mono text-emerald-400 font-bold text-sm sm:text-base tabular-nums">
                        ₹24,850
                      </span>
                    </div>
                    <div className="border-l border-slate-800 pl-4">
                      <span className="text-slate-400 text-[11px] block">Appointments</span>
                      <span className="font-mono text-white font-bold text-sm sm:text-base tabular-nums">
                        18 Total
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Tab Body */}
              <div className="p-4 sm:p-5 min-h-[290px] flex flex-col justify-between">
                
                {activeTab === 'calendar' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="font-medium text-slate-300 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-[#38BDF8]" /> Today's Live Schedule
                      </span>
                      <span className="font-mono tabular-nums text-slate-500">3 slots remaining</span>
                    </div>

                    {/* Booking item 1 */}
                    <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 flex items-center justify-between gap-3 hover:bg-slate-800/80 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 font-bold text-xs">
                          PS
                        </div>
                        <div>
                          <div className="text-white text-xs sm:text-sm font-semibold">Pooja Sharma</div>
                          <div className="text-slate-400 text-xs">Keratin Hair Spa & Layer Cut · ₹2,800</div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs font-mono text-emerald-400 font-medium">02:30 PM</div>
                        <div className="text-[11px] text-slate-400">Stylist: Sameer (Chair 1)</div>
                      </div>
                    </div>

                    {/* Booking item 2 */}
                    <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 flex items-center justify-between gap-3 hover:bg-slate-800/80 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-xs">
                          RV
                        </div>
                        <div>
                          <div className="text-white text-xs sm:text-sm font-semibold">Rahul Verma</div>
                          <div className="text-slate-400 text-xs">Beard Grooming & O3+ D-Tan · ₹1,200</div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs font-mono text-[#38BDF8] font-medium">03:15 PM</div>
                        <div className="text-[11px] text-slate-400">Stylist: Arjun (Chair 3)</div>
                      </div>
                    </div>

                    {/* Booking item 3 */}
                    <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 flex items-center justify-between gap-3 hover:bg-slate-800/80 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xs">
                          PP
                        </div>
                        <div>
                          <div className="text-white text-xs sm:text-sm font-semibold">Priya Patel</div>
                          <div className="text-slate-400 text-xs">Bridal Hair Trial & Manicure · ₹3,500</div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs font-mono text-amber-400 font-medium">04:00 PM</div>
                        <div className="text-[11px] text-slate-400">Stylist: Neha (VIP Room)</div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'billing' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="font-medium text-slate-300 flex items-center gap-1.5">
                        <Receipt className="w-3.5 h-3.5 text-emerald-400" /> Quick POS Billing
                      </span>
                      <span className="font-mono text-xs text-slate-500">Bill #INV-2026-089</span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2.5">
                      <div className="flex justify-between text-xs text-slate-300 pb-2 border-b border-slate-700">
                        <span>L'Oreal Hair Spa (60 min)</span>
                        <span className="font-mono tabular-nums">₹1,500</span>
                      </div>
                      <div className="flex justify-between text-xs text-slate-300 pb-2 border-b border-slate-700">
                        <span>Beard Trim & Oil Massage</span>
                        <span className="font-mono tabular-nums">₹450</span>
                      </div>
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>GST (18%)</span>
                        <span className="font-mono tabular-nums">₹351</span>
                      </div>
                      <div className="flex justify-between text-sm font-bold text-white pt-1">
                        <span>Grand Total</span>
                        <span className="font-mono text-emerald-400 text-base tabular-nums">₹2,301</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="p-2 bg-emerald-950/40 border border-emerald-700/50 rounded-lg text-center text-emerald-300 font-medium">
                        Instant UPI QR
                      </div>
                      <div className="p-2 bg-slate-800/80 border border-slate-700 rounded-lg text-center text-slate-300">
                        Card / POS
                      </div>
                      <div className="p-2 bg-slate-800/80 border border-slate-700 rounded-lg text-center text-slate-300">
                        Cash
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'whatsapp' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="font-medium text-slate-300 flex items-center gap-1.5">
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" /> WhatsApp Automated Alerts
                      </span>
                      <span className="text-[11px] text-emerald-400 bg-emerald-950/70 px-2 py-0.5 rounded border border-emerald-800/60">
                        Connected
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-800/40 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> 2-Hour Appointment Reminder Sent
                        </span>
                        <span className="text-slate-400 font-mono text-[11px]">Just now</span>
                      </div>
                      <p className="text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800 leading-relaxed font-mono">
                        "Namaste Pooja Ji! Glamour Salon mein aapka Hair Spa appointment aaj 02:30 PM par scheduled hai with stylist Sameer. See you soon! ✂️✨"
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/60 text-xs text-slate-300 flex items-center justify-between">
                      <span>Automated Feedback & Digital Invoice Link</span>
                      <span className="text-emerald-400 font-mono text-[11px]">Enabled</span>
                    </div>
                  </div>
                )}

                {/* Bottom interactive action */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>Salon OS v2.6 · Cloud Synced</span>
                  </div>
                  <button
                    onClick={handlePrimaryClick}
                    className="text-[#EC4899] hover:text-pink-300 font-medium transition-colors cursor-pointer"
                  >
                    Try on your salon data →
                  </button>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
