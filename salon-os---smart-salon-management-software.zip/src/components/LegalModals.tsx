import React from 'react';
import { X } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'privacy' | 'terms';
}

export const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, type }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[85vh] bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-left">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">
            {type === 'privacy' ? 'Privacy Policy — Salon OS' : 'Terms of Service — Salon OS'}
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {type === 'privacy' ? (
            <>
              <p>
                <strong>Last Updated: October 2026</strong>
              </p>
              <p>
                Salon OS ("we", "our", or "us") is dedicated to protecting the privacy of salon owners and business representatives who register for our software demonstrations and services.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">1. Information We Collect</h4>
              <p>
                When you request a free software demo or WhatsApp enquiry, we collect the details you voluntarily submit: your Full Name, WhatsApp Contact Number, Salon/Business Name, City, Salon Type, Staff Count, and Operational Challenges.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">2. How We Use Your Data</h4>
              <p>
                Your data is strictly used to: (a) schedule and conduct your 1-on-1 personalized software demonstration, (b) communicate operational setup details via WhatsApp or phone, and (c) answer your technical queries regarding billing, hardware, and CRM integration.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">3. Zero Third-Party Selling</h4>
              <p>
                We never sell, lease, or rent your personal information to third-party advertisers or lead brokers. All communications are direct between Salon OS and your business.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">4. Communications & Opt-Out</h4>
              <p>
                You may opt-out of demo updates at any point simply by replying "STOP" or "UNSUBSCRIBE" on WhatsApp or emailing us at privacy@salonos.in.
              </p>
            </>
          ) : (
            <>
              <p>
                <strong>Last Updated: October 2026</strong>
              </p>
              <p>
                By requesting a demonstration or accessing the Salon OS landing platform, you agree to these Terms of Service.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">1. Demonstration & Walkthroughs</h4>
              <p>
                The free live demonstration is provided on an as-available basis for genuine salon owners, managers, and beauty wellness operators in India. No payment or credit card is required to receive a demonstration.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">2. Third-Party Integrations</h4>
              <p>
                Certain features such as WhatsApp Business API messaging require third-party verification and standard Meta API approval. Hardware compatibility (thermal printers, barcode scanners) depends on individual hardware specifications.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">3. Intellectual Property</h4>
              <p>
                Salon OS, the software dashboard designs, workflows, and brand assets are proprietary and protected under applicable intellectual property laws.
              </p>
              <h4 className="text-sm font-bold text-white pt-2">4. Contact Information</h4>
              <p>
                For official inquiries or support, contact support@salonos.in.
              </p>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
