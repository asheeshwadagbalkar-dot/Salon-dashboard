import React from 'react';
import { MessageCircle, Mail, ShieldCheck } from 'lucide-react';
import { buildWhatsAppLink, trackMetaPixelEvent } from '../utils/analytics';

interface FooterProps {
  whatsappNumber: string;
  supportEmail: string;
  onOpenPrivacyModal: () => void;
  onOpenTermsModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  whatsappNumber,
  supportEmail,
  onOpenPrivacyModal,
  onOpenTermsModal,
}) => {
  const currentYear = 2026;

  return (
    <footer className="bg-[#070C1B] border-t border-slate-900 text-slate-400 py-12 md:py-16 text-xs sm:text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-slate-850">
          
          {/* Brand Info */}
          <div className="md:col-span-6 space-y-3">
            <div className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
              <span>Salon</span>
              <span className="text-[#EC4899]">OS</span>
            </div>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Smart salon management software built for Indian beauty parlours, hair salons, unisex salons, and salon chains. Appointments, POS billing, staff rosters, CRM, and WhatsApp workflows in one unified dashboard.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Registered SaaS · Tailored for Indian Businesses</span>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              Explore
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#features" className="hover:text-white transition-colors">
                  10 Core Modules
                </a>
              </li>
              <li>
                <a href="#video-demo" className="hover:text-white transition-colors">
                  2-Minute Video Tour
                </a>
              </li>
              <li>
                <a href="#before-after" className="hover:text-white transition-colors">
                  Before vs After Comparison
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-white transition-colors">
                  3-Step Onboarding
                </a>
              </li>
              <li>
                <a href="#faqs" className="hover:text-white transition-colors">
                  Frequently Asked Questions
                </a>
              </li>
            </ul>
          </div>

          {/* Direct Contact & Support */}
          <div className="md:col-span-3 space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              Contact & Enquiries
            </h4>
            <div className="space-y-2 text-xs">
              <a
                href={buildWhatsAppLink(whatsappNumber)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackMetaPixelEvent('Contact', { channel: 'footer_whatsapp' })}
                className="flex items-center gap-2 text-[#25D366] hover:text-green-300 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp: +{whatsappNumber}</span>
              </a>

              <a
                href={`mailto:${supportEmail}`}
                className="flex items-center gap-2 hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4 text-slate-400" />
                <span>{supportEmail}</span>
              </a>

              <p className="text-[11px] text-slate-400 pt-2">
                Mon - Sat · 10:00 AM to 7:30 PM IST
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {currentYear} Salon OS. All rights reserved.
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={onOpenPrivacyModal}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span aria-hidden="true" className="text-slate-800">·</span>
            <button
              onClick={onOpenTermsModal}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Terms of Service
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
