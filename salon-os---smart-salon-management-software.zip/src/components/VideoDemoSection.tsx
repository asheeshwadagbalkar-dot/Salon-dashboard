import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  RotateCcw,
  Captions,
  Upload,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { trackMetaPixelEvent } from '../utils/analytics';

interface VideoDemoSectionProps {
  onLiveDemoClick: () => void;
}

interface Chapter {
  id: number;
  title: string;
  timeSec: number;
  label: string;
  hindiSub: string;
  engSub: string;
}

export const VideoDemoSection: React.FC<VideoDemoSectionProps> = ({ onLiveDemoClick }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(89); // Default 01:29
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showCaptions, setShowCaptions] = useState<boolean>(true);
  const [customVideoSrc, setCustomVideoSrc] = useState<string>('/salon-os-demo.mp4');
  const [activeChapterIndex, setActiveChapterIndex] = useState<number>(0);

  const chapters: Chapter[] = [
    {
      id: 1,
      title: 'Intro & Dashboard Overview',
      timeSec: 0,
      label: '0:00 Overview',
      hindiSub: 'Salon chalana sirf haircuts tak limited nahi hai — appointments, billing aur customers sab manage karein.',
      engSub: 'Running a salon is more than haircuts — manage appointments, billing, staff and customers in one place.',
    },
    {
      id: 2,
      title: 'Appointments & Calendar',
      timeSec: 20,
      label: '0:20 Appointments',
      hindiSub: 'Appointments & Calendar section mein bookings ko organize karein. Double-booking ka zero risk.',
      engSub: 'Organize bookings chair-wise with real-time multi-stylist calendar schedule.',
    },
    {
      id: 3,
      title: 'POS Billing & GST UPI',
      timeSec: 30,
      label: '0:30 POS Billing',
      hindiSub: 'POS & Billing se 10 seconds mein GST bill banayein aur on-screen dynamic UPI QR scan karwayein.',
      engSub: 'Generate 10-second GST bills with instant on-screen UPI QR code collection.',
    },
    {
      id: 4,
      title: 'Staff, CRM & WhatsApp',
      timeSec: 45,
      label: '0:45 Staff & CRM',
      hindiSub: 'Stylists ka attendance, commission hisab aur WhatsApp automated reminder alerts ek jagah.',
      engSub: 'Track stylist commissions, client formula notes and automated WhatsApp appointment reminders.',
    },
    {
      id: 5,
      title: 'Reports & Live Demo Booking',
      timeSec: 67,
      label: '1:07 Reports & Demo',
      hindiSub: 'Daily sales reports dekhein aur Ashish Digital Solutions team se apna personalized demo schedule karein.',
      engSub: 'Review daily revenue analytics and schedule your free 1-on-1 personalized live demo.',
    },
  ];

  // Update current chapter as playback progresses
  useEffect(() => {
    let currentIdx = 0;
    for (let i = chapters.length - 1; i >= 0; i--) {
      if (currentTime >= chapters[i].timeSec) {
        currentIdx = i;
        break;
      }
    }
    setActiveChapterIndex(currentIdx);
  }, [currentTime]);

  const togglePlay = () => {
    if (!videoRef.current) return;

    if (videoRef.current.paused || videoRef.current.ended) {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
        trackMetaPixelEvent('ViewContent', { content_name: 'Played Walkthrough Demo Video' });
      }).catch((_err) => {
        // Autoplay policy fallback
      });
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (videoRef.current.duration && !isNaN(videoRef.current.duration)) {
        setDuration(videoRef.current.duration);
      }
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const targetSec = ratio * duration;
    videoRef.current.currentTime = targetSec;
    setCurrentTime(targetSec);
  };

  const jumpToChapter = (sec: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = sec;
      setCurrentTime(sec);
      if (videoRef.current.paused) {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const restartVideo = () => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = 0;
    setCurrentTime(0);
    videoRef.current.play().catch(() => {});
    setIsPlaying(true);
  };

  const toggleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const handleCustomFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const blobUrl = URL.createObjectURL(file);
      setCustomVideoSrc(blobUrl);
      setIsPlaying(false);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.load();
        }
      }, 100);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const currentChapter = chapters[activeChapterIndex] || chapters[0];

  return (
    <section id="video-demo" className="py-16 md:py-24 bg-[#090F21] border-b border-slate-800/80">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-8 md:mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#EC4899] bg-[#EC4899]/10 px-3 py-1 rounded-md border border-[#EC4899]/20 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
            <span>Official Video Walkthrough</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Sirf 2 Minute Mein Dekhiye Salon OS Kaise Kaam Karta Hai.
          </h2>

          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Aapke salon ke daily hisab-kitab, appointments calendar, POS billing, aur staff management ka real software demonstration dekhiye.
          </p>
        </div>

        {/* Video Player Shell (16:9 Aspect Ratio) */}
        <div className="relative rounded-2xl md:rounded-3xl bg-slate-950 border border-slate-700/80 shadow-2xl overflow-hidden aspect-[16/9] flex flex-col justify-between group">
          
          {/* HTML5 Video Element */}
          <video
            ref={videoRef}
            src={customVideoSrc}
            poster="/video-poster.png"
            playsInline
            preload="metadata"
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setIsPlaying(false)}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onClick={togglePlay}
            className="absolute inset-0 w-full h-full object-cover cursor-pointer bg-slate-950"
          />

          {/* Top Video Header Overlay */}
          <div className="absolute top-0 left-0 right-0 p-3 sm:p-5 bg-gradient-to-b from-black/85 via-black/40 to-transparent z-10 flex items-center justify-between text-xs sm:text-sm text-white pointer-events-none">
            <div className="flex items-center gap-2 pointer-events-auto">
              <span className="font-bold text-white tracking-wide">Salon OS</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300 hidden sm:inline">Product Demo Walkthrough (01:29)</span>
            </div>

            <div className="flex items-center gap-3 pointer-events-auto">
              <span className="px-2.5 py-1 rounded-lg bg-slate-900/90 text-xs font-mono text-[#38BDF8] border border-slate-700/80">
                Chapter {currentChapter.id}/5: {currentChapter.title}
              </span>

              {/* Local File Selector for testing custom MP4 */}
              <label
                title="Play another MP4 video file"
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-[11px] text-slate-300 hover:text-white border border-slate-700 cursor-pointer transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Replace Video</span>
                <input
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime"
                  onChange={handleCustomFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Subtitles Overlay (Synchronized with speech) */}
          {showCaptions && (
            <div className="absolute bottom-16 sm:bottom-20 left-4 right-4 z-20 pointer-events-none text-center">
              <div className="inline-block max-w-2xl px-4 py-2 rounded-xl bg-black/90 text-amber-300 border border-slate-800 shadow-xl backdrop-blur-sm text-xs sm:text-sm font-medium leading-relaxed">
                <span className="text-white block sm:inline mr-2">[Hindi]</span>
                "{currentChapter.hindiSub}"
              </div>
            </div>
          )}

          {/* Large Center Play Overlay (visible when paused) */}
          {!isPlaying && (
            <div
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/35 z-10 cursor-pointer"
            >
              <button
                type="button"
                aria-label="Play video walkthrough"
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-[#D946EF] to-[#E11D48] text-white flex items-center justify-center shadow-2xl shadow-pink-900/60 hover:scale-105 active:scale-95 transition-transform cursor-pointer"
              >
                <Play className="w-7 h-7 sm:w-9 sm:h-9 ml-1 fill-white" />
              </button>
            </div>
          )}

          {/* Bottom Player Controls Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 bg-gradient-to-t from-black/95 via-black/80 to-transparent z-20 space-y-2">
            
            {/* Scrubber Timeline Bar */}
            <div
              onClick={handleSeek}
              className="relative w-full h-2 sm:h-2.5 bg-slate-800/90 rounded-full cursor-pointer overflow-hidden group"
            >
              <div
                className="h-full bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#38BDF8] rounded-full transition-all duration-75"
                style={{ width: `${(currentTime / (duration || 89)) * 100}%` }}
              />
            </div>

            {/* Playback Controls & Timestamp Indicators */}
            <div className="flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-3 sm:gap-4">
                <button
                  type="button"
                  onClick={togglePlay}
                  className="hover:text-white transition-colors cursor-pointer"
                  aria-label={isPlaying ? 'Pause video' : 'Play video'}
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={restartVideo}
                  className="hover:text-white transition-colors cursor-pointer"
                  title="Replay from beginning"
                  aria-label="Replay from beginning"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <div className="font-mono text-xs tabular-nums text-slate-400">
                  <span className="text-white font-semibold">{formatTime(currentTime)}</span> / {formatTime(duration)}
                </div>
              </div>

              {/* Chapter Jump Buttons */}
              <div className="hidden lg:flex items-center gap-1.5">
                {chapters.map((ch, idx) => (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => jumpToChapter(ch.timeSec)}
                    className={`px-2.5 py-1 text-[11px] rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                      activeChapterIndex === idx
                        ? 'bg-[#D946EF]/25 text-[#EC4899] font-semibold border border-[#D946EF]/40'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    {ch.label}
                  </button>
                ))}
              </div>

              {/* Utility Tools: Captions, Volume, Fullscreen */}
              <div className="flex items-center gap-3 sm:gap-4">
                <button
                  type="button"
                  onClick={() => setShowCaptions(!showCaptions)}
                  className={`transition-colors cursor-pointer ${
                    showCaptions ? 'text-amber-400' : 'text-slate-500'
                  }`}
                  title="Toggle Hindi/English Captions"
                  aria-label="Toggle Hindi/English Captions"
                >
                  <Captions className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={toggleMute}
                  className="hover:text-white transition-colors cursor-pointer"
                  title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
                  aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-rose-400" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={toggleFullscreen}
                  className="hover:text-white transition-colors cursor-pointer hidden sm:block"
                  title="Full Screen View"
                  aria-label="Full Screen View"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Chapter Quick Cards for Mobile / Below Video */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          {chapters.map((ch, idx) => (
            <button
              key={ch.id}
              onClick={() => jumpToChapter(ch.timeSec)}
              className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                activeChapterIndex === idx
                  ? 'bg-slate-900 border-[#D946EF]/60 text-white'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="font-mono text-[10px] text-[#38BDF8] block">{ch.label}</span>
              <span className="font-semibold text-xs truncate block">{ch.title}</span>
            </button>
          ))}
        </div>

        {/* Call To Action Below Video */}
        <div className="mt-10 text-center space-y-3">
          <button
            onClick={() => {
              trackMetaPixelEvent('ViewContent', { content_name: 'Video Demo CTA Button' });
              onLiveDemoClick();
            }}
            className="px-8 sm:px-10 py-4 text-base font-bold text-white bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#F43F5E] hover:from-[#C026D3] hover:to-[#BE123C] rounded-2xl shadow-xl shadow-pink-900/40 transition-all duration-150 transform hover:-translate-y-0.5 cursor-pointer inline-flex items-center gap-2.5"
          >
            <span>Mujhe Live Demo Chahiye</span>
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded font-mono">100% Free Walkthrough</span>
          </button>

          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Aapke salon ke rate card, chairs aur staff ke anusaar 1-on-1 personalized software tour schedule karein.
          </p>
        </div>

      </div>
    </section>
  );
};
