import React, { useState } from 'react';
import { CheckCircle2, AlertCircle, Loader2, MessageCircle, ShieldCheck, Sparkles, Building2 } from 'lucide-react';
import { LeadFormData, LeadSubmissionResponse } from '../types';
import { trackMetaPixelEvent, getUtmParameters, buildWhatsAppLink } from '../utils/analytics';

interface LeadCaptureFormProps {
  onOpenPrivacyModal: () => void;
  whatsappNumber: string;
}

export const LeadCaptureForm: React.FC<LeadCaptureFormProps> = ({ onOpenPrivacyModal, whatsappNumber }) => {
  const [formData, setFormData] = useState<LeadFormData>({
    fullName: '',
    whatsappNumber: '',
    salonName: '',
    city: '',
    salonType: 'Unisex Salon',
    staffCount: '1-3 staff',
    challenge: 'Appointments & Scheduling',
    consent: true,
    honeypot: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionResult, setSubmissionResult] = useState<LeadSubmissionResponse | null>(null);

  const salonTypes = [
    'Unisex Salon',
    'Beauty Parlour',
    'Hair Salon',
    'Spa & Wellness',
    'Salon Chain (2+ Branches)',
  ];

  const staffOptions = [
    '1-3 staff',
    '4-7 staff',
    '8-15 staff',
    '15+ staff',
  ];

  const challenges = [
    'Appointments & Double Bookings',
    'Billing, GST & Daily Sales Tracking',
    'Customer History & Retention CRM',
    'Staff Roster & Commission Calculation',
    'Inventory & Low Stock Wastage',
    'Marketing, Offers & WhatsApp Follow-ups',
    'Other Salon Operations',
  ];

  const validatePhone = (phone: string) => {
    const cleanDigits = phone.replace(/\D/g, '');
    let normalized = cleanDigits;
    if (normalized.length === 12 && normalized.startsWith('91')) {
      normalized = normalized.slice(2);
    } else if (normalized.length === 11 && normalized.startsWith('0')) {
      normalized = normalized.slice(1);
    }
    return /^[6-9]\d{9}$/.test(normalized);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Field validations
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim() || formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Kripya apna poora naam enter karein.';
    }

    if (!validatePhone(formData.whatsappNumber)) {
      newErrors.whatsappNumber = 'Kripya ek valid 10-digit Indian WhatsApp number enter karein (starts with 6, 7, 8, or 9).';
    }

    if (!formData.salonName.trim() || formData.salonName.trim().length < 2) {
      newErrors.salonName = 'Kripya apne salon ka naam enter karein.';
    }

    if (!formData.city.trim() || formData.city.trim().length < 2) {
      newErrors.city = 'Kripya apna city enter karein (e.g. Mumbai, Delhi, Pune).';
    }

    if (!formData.consent) {
      newErrors.consent = 'Demo slot book karne ke liye communication consent zaroori hai.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      const utms = getUtmParameters();
      const payload = {
        ...formData,
        ...utms,
        variant: 'meta_landing_v1',
      };

      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const result: LeadSubmissionResponse = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Submission failed. Kripya punah prayas karein.');
      }

      setSubmissionResult(result);

      // Track Meta Pixel Lead event
      trackMetaPixelEvent('Lead', {
        salon_name: formData.salonName,
        city: formData.city,
        salon_type: formData.salonType,
        challenge: formData.challenge,
      });

    } catch (err: any) {
      setErrors({
        form: err.message || 'Network error. Kripya punah prayas karein.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSubmissionResult(null);
    setFormData({
      fullName: '',
      whatsappNumber: '',
      salonName: '',
      city: '',
      salonType: 'Unisex Salon',
      staffCount: '1-3 staff',
      challenge: 'Appointments & Scheduling',
      consent: true,
      honeypot: '',
    });
  };

  return (
    <section id="lead-form" className="py-16 md:py-24 bg-[#0B132B] border-b border-slate-800/80 relative">
      {/* Decorative ambient background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[#D946EF]/5 blur-3xl pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-[#EC4899] font-semibold block mb-2">
            Priority VIP Onboarding
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Apne Salon Ko Smart Banane Ka Pehla Step Lijiye.
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Form fill karein — hamare salon technology specialist aapse WhatsApp par connect karke 1-on-1 personalized demo arrange karenge.
          </p>
        </div>

        {/* Card Container */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          
          {/* Success Confirmation State */}
          {submissionResult && submissionResult.success ? (
            <div className="py-8 text-center space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                  Demo Slot Reserved Ho Gaya Hai!
                </h3>
                <p className="text-sm sm:text-base text-slate-300 max-w-md mx-auto">
                  {submissionResult.isDuplicate
                    ? 'Aapka request hamare paas pehle se recorded hai. Hamari team aapse jald hi sampark karegi.'
                    : `Namaste ${formData.fullName}! ${formData.salonName} ke liye Salon OS live demo booking record ho gayi hai.`}
                </p>
              </div>

              {/* Verified Details Card */}
              <div className="max-w-md mx-auto p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-left text-xs sm:text-sm space-y-2">
                <div className="flex justify-between pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Salon Name:</span>
                  <span className="text-white font-semibold">{formData.salonName}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-slate-800">
                  <span className="text-slate-400">City:</span>
                  <span className="text-white font-semibold">{formData.city}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-slate-800">
                  <span className="text-slate-400">WhatsApp:</span>
                  <span className="text-white font-mono">{formData.whatsappNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Reference ID:</span>
                  <span className="text-emerald-400 font-mono text-[11px]">{submissionResult.leadId}</span>
                </div>
              </div>

              {/* Instant WhatsApp Connect Button */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href={buildWhatsAppLink(whatsappNumber, formData.salonName, formData.city)}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackMetaPixelEvent('Contact', { type: 'whatsapp_post_submission' })}
                  className="w-full sm:w-auto px-6 py-3.5 text-sm font-bold text-white bg-[#25D366] hover:bg-[#20BD5A] rounded-xl shadow-lg shadow-green-950/50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5 fill-current" />
                  <span>Connect Directly on WhatsApp</span>
                </a>

                <button
                  onClick={resetForm}
                  className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
                >
                  Book for another branch
                </button>
              </div>
            </div>
          ) : (
            
            /* The Active Lead Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Spam Honeypot - Hidden from humans */}
              <div className="hidden" aria-hidden="true">
                <input
                  type="text"
                  name="honeypot"
                  tabIndex={-1}
                  value={formData.honeypot}
                  onChange={handleInputChange}
                  autoComplete="off"
                />
              </div>

              {/* General Form Error Notice */}
              {errors.form && (
                <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs sm:text-sm text-rose-300 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  <span>{errors.form}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                
                {/* 1. Full Name */}
                <div className="space-y-1.5">
                  <label htmlFor="fullName" className="block text-xs font-semibold text-slate-200">
                    Aapka Poora Naam <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    placeholder="e.g. Ramesh Sharma"
                    className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-white text-sm focus:outline-none transition-colors ${
                      errors.fullName
                        ? 'border-rose-500 focus:border-rose-400'
                        : 'border-slate-700/80 focus:border-[#D946EF]'
                    }`}
                  />
                  {errors.fullName && (
                    <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.fullName}
                    </p>
                  )}
                </div>

                {/* 2. WhatsApp Number */}
                <div className="space-y-1.5">
                  <label htmlFor="whatsappNumber" className="block text-xs font-semibold text-slate-200">
                    WhatsApp Mobile Number <span className="text-rose-400">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm font-mono">
                      +91
                    </span>
                    <input
                      type="tel"
                      id="whatsappNumber"
                      name="whatsappNumber"
                      value={formData.whatsappNumber}
                      onChange={handleInputChange}
                      maxLength={14}
                      placeholder="98201 98201"
                      className={`w-full pl-12 pr-4 py-3 rounded-xl bg-slate-950/80 border text-white text-sm font-mono focus:outline-none transition-colors ${
                        errors.whatsappNumber
                          ? 'border-rose-500 focus:border-rose-400'
                          : 'border-slate-700/80 focus:border-[#D946EF]'
                      }`}
                    />
                  </div>
                  {errors.whatsappNumber ? (
                    <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.whatsappNumber}
                    </p>
                  ) : (
                    <p className="text-[11px] text-slate-500">Demo link WhatsApp par send kiya jayega.</p>
                  )}
                </div>

                {/* 3. Salon Name */}
                <div className="space-y-1.5">
                  <label htmlFor="salonName" className="block text-xs font-semibold text-slate-200">
                    Salon / Parlour Ka Naam <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    id="salonName"
                    name="salonName"
                    value={formData.salonName}
                    onChange={handleInputChange}
                    placeholder="e.g. Looks Unisex Salon"
                    className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-white text-sm focus:outline-none transition-colors ${
                      errors.salonName
                        ? 'border-rose-500 focus:border-rose-400'
                        : 'border-slate-700/80 focus:border-[#D946EF]'
                    }`}
                  />
                  {errors.salonName && (
                    <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.salonName}
                    </p>
                  )}
                </div>

                {/* 4. City */}
                <div className="space-y-1.5">
                  <label htmlFor="city" className="block text-xs font-semibold text-slate-200">
                    City / Shehar <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    placeholder="e.g. Mumbai, Surat, Lucknow"
                    className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-white text-sm focus:outline-none transition-colors ${
                      errors.city
                        ? 'border-rose-500 focus:border-rose-400'
                        : 'border-slate-700/80 focus:border-[#D946EF]'
                    }`}
                  />
                  {errors.city && (
                    <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5" /> {errors.city}
                    </p>
                  )}
                </div>

                {/* 5. Salon Type */}
                <div className="space-y-1.5">
                  <label htmlFor="salonType" className="block text-xs font-semibold text-slate-200">
                    Salon Type <span className="text-rose-400">*</span>
                  </label>
                  <select
                    id="salonType"
                    name="salonType"
                    value={formData.salonType}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-[#D946EF] transition-colors cursor-pointer"
                  >
                    {salonTypes.map((type) => (
                      <option key={type} value={type} className="bg-slate-900 text-white">
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 6. Number of Staff */}
                <div className="space-y-1.5">
                  <label htmlFor="staffCount" className="block text-xs font-semibold text-slate-200">
                    Number of Staff / Stylists
                  </label>
                  <select
                    id="staffCount"
                    name="staffCount"
                    value={formData.staffCount}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-[#D946EF] transition-colors cursor-pointer"
                  >
                    {staffOptions.map((opt) => (
                      <option key={opt} value={opt} className="bg-slate-900 text-white">
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* 7. Biggest Challenge */}
              <div className="space-y-1.5">
                <label htmlFor="challenge" className="block text-xs font-semibold text-slate-200">
                  Aapke Salon Ka Sabse Bada Challenge Kya Hai?
                </label>
                <select
                  id="challenge"
                  name="challenge"
                  value={formData.challenge}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-[#D946EF] transition-colors cursor-pointer"
                >
                  {challenges.map((ch) => (
                    <option key={ch} value={ch} className="bg-slate-900 text-white">
                      {ch}
                    </option>
                  ))}
                </select>
              </div>

              {/* Consent Checkbox */}
              <div className="space-y-1 pt-1">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    name="consent"
                    checked={formData.consent}
                    onChange={handleInputChange}
                    className="mt-1 w-4 h-4 rounded border-slate-700 bg-slate-950 text-[#D946EF] focus:ring-0 cursor-pointer"
                  />
                  <span className="text-xs text-slate-300 leading-relaxed">
                    Main WhatsApp aur phone par Salon OS free demo schedule aur updates paane ke liye consent deta/deti hoon. Ham aapki information kisi third-party ke sath share nahi karte. View{' '}
                    <button
                      type="button"
                      onClick={onOpenPrivacyModal}
                      className="text-[#38BDF8] hover:underline cursor-pointer font-medium"
                    >
                      Privacy Policy
                    </button>
                    .
                  </span>
                </label>
                {errors.consent && (
                  <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" /> {errors.consent}
                  </p>
                )}
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 text-base font-bold text-white bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#F43F5E] hover:from-[#C026D3] hover:to-[#BE123C] rounded-xl shadow-xl shadow-pink-900/40 transition-all duration-150 transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Slot Confirm Ho Raha Hai...</span>
                    </>
                  ) : (
                    <>
                      <span>Book My FREE Demo</span>
                      <Sparkles className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              {/* Trust Footer */}
              <div className="text-center pt-2">
                <span className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>100% Free · No Credit Card Required · Dedicated Indian Support</span>
                </span>
              </div>

            </form>
          )}

        </div>

      </div>
    </section>
  );
};
