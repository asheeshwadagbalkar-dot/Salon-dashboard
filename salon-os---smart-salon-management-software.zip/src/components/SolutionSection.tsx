import React, { useState } from 'react';
import {
  Calendar,
  Receipt,
  Users,
  UserCheck,
  Package,
  MessageSquare,
  BarChart3,
  Sparkles,
  Tag,
  Globe,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { FeatureModule } from '../types';

interface SolutionSectionProps {
  onBookDemoClick: () => void;
}

export const SolutionSection: React.FC<SolutionSectionProps> = ({ onBookDemoClick }) => {
  const [selectedModuleId, setSelectedModuleId] = useState<string>('appointments');

  const modules: FeatureModule[] = [
    {
      id: 'appointments',
      number: '01',
      title: 'Appointments & Calendar',
      tagline: 'Bookings aur schedules ko organize karein',
      description: 'Single digital calendar jisme har chair, stylist aur treatment slot real-time sync hota hai. Double-booking aur no-shows se mukti.',
      details: [
        'Color-coded chair & stylist view',
        'Quick 3-click walk-in booking',
        'Automatic slot collision prevention',
        'Mobile & tablet friendly calendar',
      ],
      iconName: 'Calendar',
    },
    {
      id: 'pos',
      number: '02',
      title: 'POS & Billing',
      tagline: 'Bills aur sales records manage karein',
      description: '10 seconds mein professional GST ya Non-GST bill banayein. Cash, UPI, Card aur split payment ka accurate hisab.',
      details: [
        'Instant UPI QR generation on screen',
        'Thermal printer & WhatsApp PDF bill support',
        'Service + Product combo billing in one invoice',
        'Daily cash drawer reconciliation',
      ],
      iconName: 'Receipt',
    },
    {
      id: 'crm',
      number: '03',
      title: 'Customer CRM',
      tagline: 'Client profiles aur visit history ko organize karein',
      description: 'Har client ki complete history — kab kaunsa treatment karwaya, hair color shades, allergic notes aur birthday details.',
      details: [
        'Client profile with visit count & total spend',
        'Formula & note storage (e.g. hair dye shade)',
        'Membership balance & package sessions balance',
        'VIP client auto-tagging',
      ],
      iconName: 'Users',
    },
    {
      id: 'staff',
      number: '04',
      title: 'Staff & Roster',
      tagline: 'Staff scheduling aur management',
      description: 'Stylist attendance, duty timings, chair allocation aur service commission calculation transparently track karein.',
      details: [
        'Daily attendance & duty shifts',
        'Automatic commission calculation per service',
        'Stylist-wise daily sales report',
        'Individual staff login with permission controls',
      ],
      iconName: 'UserCheck',
    },
    {
      id: 'inventory',
      number: '05',
      title: 'Inventory & Products',
      tagline: 'Product stock tracking',
      description: 'Salon consumption (shampoo, colors, wax) aur retail selling products ka live stock track karein. Wastage aur theft control karein.',
      details: [
        'Low stock automatic alert notification',
        'Backbar consumption vs retail sales tracking',
        'Expiry date tracking for chemical treatments',
        'Vendor purchase order management',
      ],
      iconName: 'Package',
    },
    {
      id: 'whatsapp',
      number: '06',
      title: 'WhatsApp Automation',
      tagline: 'Supported messaging workflows',
      description: 'Clients ko automated booking confirmations, 2-hour appointment reminders, birthday greetings aur digital bills deliver karein.',
      details: [
        'Instant booking confirmation with salon address',
        'Smart 2-hour before arrival reminder',
        'Digital bill link sent directly to WhatsApp',
        'Post-service review collection trigger',
      ],
      integrationNote: 'Requires WhatsApp Business API setup & template approval; fully configured by our onboarding specialists during setup.',
      iconName: 'MessageSquare',
    },
    {
      id: 'reports',
      number: '07',
      title: 'Reports & Analytics',
      tagline: 'Business performance visibility',
      description: 'Aapka salon kitna profit bana raha hai, kiska collection kitna hua, kaunsa service sabse zyada bikta hai — sab clear graphs mein.',
      details: [
        'Daily, weekly & monthly sales summary',
        'Payment mode split (UPI vs Cash vs Card)',
        'Top 10 most profitable salon services',
        'Customer repeat rate & churn metrics',
      ],
      iconName: 'BarChart3',
    },
    {
      id: 'services',
      number: '08',
      title: 'Services & Packages',
      tagline: 'Salon service catalog and packages',
      description: 'Hair cut, spa, facial, bridal packages, multi-sitting bundles aur seasonal combos ko customized rate card mein organize karein.',
      details: [
        'Category-wise rate card (Hair, Skin, Nails, Spa)',
        'Bridal & Groom custom package builder',
        'Multi-session prepaid cards with balance tracker',
        'Dynamic service duration by stylist level',
      ],
      iconName: 'Sparkles',
    },
    {
      id: 'coupons',
      number: '09',
      title: 'Coupons & Marketing',
      tagline: 'Promotional workflows',
      description: 'Diwali, wedding season ya slow weekdays par discount coupons aur cashback campaigns create karein jo POS par automatically apply hon.',
      details: [
        'Percentage or flat INR discount codes',
        'Minimum bill value validation',
        'One-time use client coupons',
        'Referral reward tracking for existing clients',
      ],
      iconName: 'Tag',
    },
    {
      id: 'booking_page',
      number: '10',
      title: 'Customer Booking Page',
      tagline: 'Online booking interface',
      description: 'Apne salon ka branded web booking link payein. Isko Instagram bio, WhatsApp catalog ya Google Business Profile par link karein.',
      details: [
        'Mobile-friendly branded booking link',
        'Customers choose service, stylist & preferred time',
        'Real-time available slot sync with POS calendar',
        'Zero commission on self-bookings',
      ],
      iconName: 'Globe',
    },
  ];

  const activeModule = modules.find((m) => m.id === selectedModuleId) || modules[0];

  const renderModuleIcon = (iconName: string) => {
    switch (iconName) {
      case 'Calendar': return <Calendar className="w-5 h-5 text-[#38BDF8]" />;
      case 'Receipt': return <Receipt className="w-5 h-5 text-emerald-400" />;
      case 'Users': return <Users className="w-5 h-5 text-pink-400" />;
      case 'UserCheck': return <UserCheck className="w-5 h-5 text-purple-400" />;
      case 'Package': return <Package className="w-5 h-5 text-amber-400" />;
      case 'MessageSquare': return <MessageSquare className="w-5 h-5 text-emerald-400" />;
      case 'BarChart3': return <BarChart3 className="w-5 h-5 text-cyan-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-rose-400" />;
      case 'Tag': return <Tag className="w-5 h-5 text-indigo-400" />;
      case 'Globe': return <Globe className="w-5 h-5 text-sky-400" />;
      default: return <Sparkles className="w-5 h-5 text-[#38BDF8]" />;
    }
  };

  return (
    <section id="features" className="py-16 md:py-24 bg-[#0B132B] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-wider font-semibold text-[#38BDF8] mb-2">
            All-In-One Salon Operating System
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Meet Salon OS — Your Salon, One Smart Dashboard.
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Aapke salon ke har operation ko ek simple, fast aur reliable platform se connect karein.
          </p>
        </div>

        {/* Dynamic Feature Tabs Navigation (Segmented interactive buttons) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar scroll-smooth">
          {modules.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedModuleId(m.id)}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl whitespace-nowrap shrink-0 transition-all cursor-pointer flex items-center gap-2 ${
                selectedModuleId === m.id
                  ? 'bg-gradient-to-r from-[#D946EF] to-[#E11D48] text-white shadow-md shadow-pink-900/30'
                  : 'bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span className="font-mono text-[11px] opacity-75">{m.number}</span>
              <span>{m.title}</span>
            </button>
          ))}
        </div>

        {/* Feature Spotlight Card */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 lg:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left: Module Details */}
            <div className="lg:col-span-6 space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                  {renderModuleIcon(activeModule.iconName)}
                </div>
                <div>
                  <span className="text-xs font-mono text-slate-400">Module {activeModule.number}</span>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {activeModule.title}
                  </h3>
                </div>
              </div>

              <p className="text-sm sm:text-base text-slate-300 font-medium">
                {activeModule.tagline}
              </p>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                {activeModule.description}
              </p>

              <div className="space-y-2.5 pt-2">
                {activeModule.details.map((detail, idx) => (
                  <div key={idx} className="flex items-center gap-2.5 text-xs sm:text-sm text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{detail}</span>
                  </div>
                ))}
              </div>

              {/* Explicit Integration Note when applicable */}
              {activeModule.integrationNote && (
                <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200 flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{activeModule.integrationNote}</span>
                </div>
              )}

              <div className="pt-3">
                <button
                  onClick={onBookDemoClick}
                  className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer flex items-center gap-2"
                >
                  <span>See {activeModule.title} in Free Demo</span>
                  <span className="text-pink-400">→</span>
                </button>
              </div>
            </div>

            {/* Right: Realistic In-App Interface Mockup for Selected Module */}
            <div className="lg:col-span-6">
              <div className="rounded-2xl bg-slate-950/90 border border-slate-700/80 p-5 shadow-xl">
                
                {/* Module Window Header */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800 text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">Salon OS · {activeModule.title}</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400">Live Simulation</span>
                </div>

                {/* Module Specific Screen Content */}
                <div className="py-4 space-y-3 min-h-[260px]">
                  {activeModule.id === 'appointments' && (
                    <div className="space-y-2.5">
                      <div className="grid grid-cols-3 gap-2 text-center text-xs pb-2 border-b border-slate-800">
                        <div className="p-1.5 bg-slate-900 rounded font-medium text-slate-300">Chair 1: Sameer</div>
                        <div className="p-1.5 bg-slate-900 rounded font-medium text-slate-300">Chair 2: Neha</div>
                        <div className="p-1.5 bg-slate-900 rounded font-medium text-slate-300">Chair 3: Arjun</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-pink-950/20 border border-pink-800/40 text-xs flex justify-between">
                        <div>
                          <span className="font-bold text-white block">Pooja S. (Hair Spa)</span>
                          <span className="text-[11px] text-slate-400">02:30 PM - 03:30 PM</span>
                        </div>
                        <span className="text-pink-400 font-mono text-[11px]">In Progress</span>
                      </div>
                      <div className="p-2.5 rounded-lg bg-cyan-950/20 border border-cyan-800/40 text-xs flex justify-between">
                        <div>
                          <span className="font-bold text-white block">Rahul V. (Beard + D-Tan)</span>
                          <span className="text-[11px] text-slate-400">03:15 PM - 04:00 PM</span>
                        </div>
                        <span className="text-cyan-400 font-mono text-[11px]">Confirmed</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900 border border-dashed border-slate-700 text-xs text-center text-slate-400">
                        + Tap to Add Walk-In Appointment
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'pos' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 bg-slate-900 rounded-xl space-y-1.5 border border-slate-800">
                        <div className="flex justify-between text-slate-300">
                          <span>Bridal Glow Facial</span>
                          <span className="font-mono">₹2,500</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Hair Spa L'Oreal</span>
                          <span className="font-mono">₹1,500</span>
                        </div>
                        <div className="flex justify-between text-slate-400 text-[11px]">
                          <span>GST (18%)</span>
                          <span className="font-mono">₹720</span>
                        </div>
                        <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-800">
                          <span>Total Amount</span>
                          <span className="font-mono text-emerald-400">₹4,720</span>
                        </div>
                      </div>
                      <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/50 flex items-center justify-between">
                        <span className="text-emerald-300 font-medium">Customer Payment: Dynamic UPI QR</span>
                        <span className="text-[11px] bg-emerald-500 text-slate-950 font-bold px-1.5 py-0.5 rounded">Scanned</span>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'crm' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-white font-bold text-sm">Pooja Sharma</span>
                          <span className="text-pink-400 font-medium bg-pink-950/50 px-2 py-0.5 rounded text-[11px]">VIP Gold Member</span>
                        </div>
                        <div className="text-slate-400 text-[11px]">Phone: +91 98201 44521 · Visits: 14 Times</div>
                        <div className="p-2 bg-slate-950 rounded border border-slate-800 mt-2">
                          <span className="text-slate-400 block text-[10px] uppercase font-mono">Stylist Formula Notes:</span>
                          <span className="text-slate-200">Majirel Shade 5.3 + 20 Vol (45 mins). Scalp sensitive. Likes green tea.</span>
                        </div>
                      </div>
                      <div className="flex justify-between text-slate-400 text-[11px] px-1">
                        <span>Lifetime Spend: <strong className="text-emerald-400 font-mono">₹24,800</strong></span>
                        <span>Package Balance: <strong className="text-white font-mono">2 Hair Spas</strong></span>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'staff' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">Sameer Khan (Senior Stylist)</span>
                          <span className="text-slate-400 text-[11px]">Present · 6 Services Completed</span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono text-emerald-400 font-semibold block">₹840 Com.</span>
                          <span className="text-[10px] text-slate-500">10% tier</span>
                        </div>
                      </div>
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">Neha Singh (Skin Specialist)</span>
                          <span className="text-slate-400 text-[11px]">Present · 4 Facials Completed</span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono text-emerald-400 font-semibold block">₹960 Com.</span>
                          <span className="text-[10px] text-slate-500">12% tier</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'inventory' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-rose-900/40 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">L'Oreal Oxydant 20 Vol (1000ml)</span>
                          <span className="text-rose-400 text-[11px]">Only 1 Bottle Left</span>
                        </div>
                        <span className="text-rose-400 bg-rose-950/60 border border-rose-800/60 px-2 py-0.5 rounded text-[11px] font-medium">
                          Low Stock Alert
                        </span>
                      </div>
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">Matrix Opti Care Shampoo</span>
                          <span className="text-slate-400 text-[11px]">8 Units in Retail Display</span>
                        </div>
                        <span className="text-emerald-400 text-[11px]">Adequate</span>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'whatsapp' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 bg-emerald-950/20 border border-emerald-800/50 rounded-xl space-y-1">
                        <div className="flex justify-between items-center text-emerald-400 font-semibold">
                          <span>Automated 2-Hour Reminder</span>
                          <span className="text-[10px] text-slate-400">Triggered 12:30 PM</span>
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed bg-slate-900/60 p-2 rounded border border-slate-800 font-mono">
                          "Hi Priya, aapka appointment Glamour Salon mein 02:30 PM par scheduled hai. Stylist: Neha. Need to reschedule? Reply 'CHANGE'."
                        </p>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 px-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Client confirmed arrival via WhatsApp</span>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'reports' && (
                    <div className="space-y-2 text-xs">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                          <span className="text-slate-400 text-[11px] block">Weekly Revenue</span>
                          <span className="text-emerald-400 font-bold font-mono text-base">₹1,42,800</span>
                        </div>
                        <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                          <span className="text-slate-400 text-[11px] block">Repeat Clients</span>
                          <span className="text-cyan-400 font-bold font-mono text-base">64.2%</span>
                        </div>
                      </div>
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                        <span className="text-slate-400 text-[11px] block mb-1">Top Service: Keratin Hair Treatment</span>
                        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div className="bg-gradient-to-r from-[#D946EF] to-[#E11D48] h-full w-[78%]" />
                        </div>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'services' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">Pre-Bridal Radiance Glow Package</span>
                          <span className="text-slate-400 text-[11px]">Includes Facial, Body Polishing & Hair Spa</span>
                        </div>
                        <span className="font-mono text-emerald-400 font-bold">₹8,999</span>
                      </div>
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-white block">Men's Executive Grooming Combo</span>
                          <span className="text-slate-400 text-[11px]">Haircut + Beard Spa + D-Tan</span>
                        </div>
                        <span className="font-mono text-emerald-400 font-bold">₹1,499</span>
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'coupons' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-xl flex justify-between items-center">
                        <div>
                          <span className="font-mono font-bold text-indigo-300 text-sm block">DIWALI20</span>
                          <span className="text-slate-400 text-[11px]">Flat 20% off on all skin facials & treatments</span>
                        </div>
                        <span className="text-emerald-400 font-mono text-[11px] bg-slate-900 px-2 py-1 rounded">Active</span>
                      </div>
                      <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                        Auto-validates minimum bill value of ₹1,500 at checkout
                      </div>
                    </div>
                  )}

                  {activeModule.id === 'booking_page' && (
                    <div className="space-y-2 text-xs">
                      <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                        <div className="flex items-center gap-2 text-sky-400">
                          <Globe className="w-4 h-4" />
                          <span className="font-mono text-[11px]">salonos.in/glamour-unisex-mumbai</span>
                        </div>
                        <p className="text-slate-300 text-[11px]">
                          Clients direct Instagram bio se 24x7 online appointment book kar sakte hain. Slots POS calendar mein real-time block ho jate hain.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
