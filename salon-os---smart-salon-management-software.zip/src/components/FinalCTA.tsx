import React from 'react';
import { ArrowUp, Sparkles, CheckCircle2 } from 'lucide-react';
import { trackMetaPixelEvent } from '../utils/analytics';

interface FinalCTAProps {
  onBookDemoClick: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onBookDemoClick }) => {
  const handleClick = () => {
    trackMetaPixelEvent('ViewContent', { content_name: 'Final CTA Bottom' });
    onBookDemoClick();
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-[#0B132B] via-[#0D1838] to-[#090F21] relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-radial from-[#D946EF]/10 via-transparent to-transparent pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        
        {/* Eyebrow badge */}
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#EC4899] bg-[#EC4899]/10 px-3.5 py-1.5 rounded-md border border-[#EC4899]/20 mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
          <span>Transform Your Salon Operations</span>
        </div>

        {/* Headline */}
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight max-w-3xl mx-auto text-balance">
          Salon Chalaiye Smartly, Manual Management Ko Kahiye Goodbye!
        </h2>

        {/* Supporting Copy */}
        <p className="mt-5 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Salon OS ka live dashboard dekhiye aur samajhiye ki ye aapke salon ke workflow mein kaise fit ho sakta hai.
        </p>

        {/* CTA Button */}
        <div className="mt-8">
          <button
            onClick={handleClick}
            className="px-8 sm:px-10 py-4 text-base sm:text-lg font-bold text-white bg-gradient-to-r from-[#D946EF] via-[#E11D48] to-[#F43F5E] hover:from-[#C026D3] hover:to-[#BE123C] rounded-2xl shadow-2xl shadow-pink-900/50 transition-all duration-150 transform hover:-translate-y-1 active:translate-y-0 cursor-pointer inline-flex items-center gap-2.5"
          >
            <span>Book Your FREE Demo Today</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

        {/* Trust Badges */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-slate-400">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-4 h-4" /> Zero Obligation Demo
          </span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>15-Minute Personalized Walkthrough</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Indian Salons Support</span>
        </div>

      </div>
    </section>
  );
};
