import { CalendarX2, ReceiptText, Users, ClockAlert, PackageX, UserMinus, ArrowDown } from 'lucide-react';

interface ProblemSectionProps {
  onExploreSolutionClick: () => void;
}

export const ProblemSection: React.FC<ProblemSectionProps> = ({ onExploreSolutionClick }) => {
  const problems = [
    {
      icon: CalendarX2,
      title: 'Appointment miss ho jate hain',
      description: 'Phone call par booking note ki, diary mein likhna bhool gaye ya ek hi time par do client aagaye. No-show aur double booking se revenue ka nuksan hota hai.',
    },
    {
      icon: ReceiptText,
      title: 'Billing aur daily sales tracking confusing hai',
      description: 'Din bhar mein kitna cash aaya aur kitna GPay/PhonePe se, shaam ko register check karte waqt hisab match nahi hota. GST calculation aur bills ka koi standard record nahi rehta.',
    },
    {
      icon: Users,
      title: 'Customer history scattered hai',
      description: 'Client ne 2 mahine pehle kaunsa hair color shade ya facial treatment karwaya tha, register ke panne palat kar dhoondna padta hai. Personalized service dena namumkin ho jata hai.',
    },
    {
      icon: ClockAlert,
      title: 'Staff schedules manage karna mushkil hai',
      description: 'Kaunsa stylist free hai, kiska kitna commission bana, kisne kitna product use kiya aur attendance ka hisab har month end par headache ban jata hai.',
    },
    {
      icon: PackageX,
      title: 'Products ka stock time par pata nahi chalta',
      description: 'Hair color tube, shampoo bottle ya facial kit kab khatam hone wali hai, tab pata chalta hai jab client chair par baitha ho. Wastage aur theft ka koi track nahi.',
    },
    {
      icon: UserMinus,
      title: 'Repeat customer follow-up manual hai',
      description: 'Jo client 30-45 din se nahi aaye unhe manual WhatsApp message bhejne ka time nahi milta. Purane customers quietly doosre salon chale jate hain.',
    },
  ];

  return (
    <section id="problems" className="py-16 md:py-24 bg-[#090F21] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-wider font-semibold text-rose-400 mb-2">
            The Daily Salon Bottlenecks
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Kya Aapke Salon Mein Bhi Ye Problems Hain?
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Manual diary, notebook aur scattered WhatsApp chat se salon chalana har din stress aur customer churn create karta hai.
          </p>
        </div>

        {/* 6 Problem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {problems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all duration-200 flex flex-col justify-between group"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mb-5 group-hover:scale-105 transition-transform">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white mb-2.5">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Transition Bridge */}
        <div className="mt-14 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-3 p-4 px-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-700/80">
            <span className="text-sm sm:text-base font-semibold text-white">
              Ab salon manage karein smarter tareeke se.
            </span>
            <button
              onClick={onExploreSolutionClick}
              className="text-xs sm:text-sm font-semibold text-[#38BDF8] hover:text-cyan-300 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Meet Salon OS below</span>
              <ArrowDown className="w-4 h-4 animate-bounce" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
