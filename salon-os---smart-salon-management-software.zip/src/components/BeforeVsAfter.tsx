import React from 'react';
import { X, Check } from 'lucide-react';

export const BeforeVsAfter: React.FC = () => {
  const comparisons = [
    {
      area: 'Bookings & Scheduling',
      before: 'Diary aur paper registers mein likhe appointments, double booking aur missed calls ka constant stress.',
      after: 'Single interactive calendar jisme har chair aur stylist ka schedule real-time organized dikhta hai.',
    },
    {
      area: 'Billing & Payments',
      before: 'Kaccha bill, manual calculator hisab, din ke aakhri ghante mein UPI aur cash payments ka confusing match.',
      after: '10-second GST / Non-GST digital bills with instant on-screen UPI QR code aur daily cash reconciliation.',
    },
    {
      area: 'Customer CRM & History',
      before: 'Client ke pichle hair colour shade ya skin treatment ki details registers ke panno mein dhoondna.',
      after: 'Ek click par customer ki complete visit history, formula notes, package sessions aur VIP status available.',
    },
    {
      area: 'Staff Management',
      before: 'Stylist attendance, incentives aur commissions ka calculation month-end par complicated paperwork ban jata hai.',
      after: 'Stylist-wise daily sales, automatic commission calculation aur clear shift attendance overview.',
    },
    {
      area: 'Product Inventory',
      before: 'Stock tab khatam milta hai jab client chair par ho; wastage aur chemical shelf-life ka track nahi.',
      after: 'Salon consumption aur retail products ka live stock count with low-stock automatic alerts.',
    },
    {
      area: 'Client Follow-ups & Reminders',
      before: 'Har client ko call ya manual message bhejte bhejte waqt nikal jata hai; purane clients follow-up ke bina slip ho jate hain.',
      after: 'Automated 2-hour appointment reminders, booking confirmations aur digital invoice links via WhatsApp.',
    },
  ];

  return (
    <section id="before-after" className="py-16 md:py-24 bg-[#0B132B] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-wider font-semibold text-cyan-400 mb-2">
            The Clear Transformation
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Manual Registers vs Salon OS Smart Operations
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-300">
            Dekhiye diary aur manual registers se smart digital software par switch karne par aapka salon workflow kaise badalta hai.
          </p>
        </div>

        {/* 2-Column Comparison Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Before Column */}
          <div className="rounded-3xl bg-slate-900/60 border border-rose-950/50 p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <X className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  Pehle: Diary & Manual Registers
                </h3>
                <span className="text-xs text-rose-400 font-medium">Scattered, Time-Consuming & Error-Prone</span>
              </div>
            </div>

            <div className="space-y-4">
              {comparisons.map((c, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/80 space-y-1">
                  <div className="text-xs font-semibold text-rose-300/80 uppercase tracking-wide">
                    {c.area}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    {c.before}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* After Column */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-emerald-900/40 p-6 sm:p-8 space-y-6 shadow-xl shadow-emerald-950/10">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Check className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  Baad Mein: Salon OS Smart Workflow
                </h3>
                <span className="text-xs text-emerald-400 font-medium">Organized, Fast & Centralized Control</span>
              </div>
            </div>

            <div className="space-y-4">
              {comparisons.map((c, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1">
                  <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wide">
                    {c.area}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                    {c.after}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
