/**
 * Meta Pixel & Event Tracking Helper
 * Safely triggers events if Pixel is loaded, while preserving user privacy and logging for testing.
 */

declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    _fbqEvents?: any[];
  }
}

export function trackMetaPixelEvent(eventName: 'PageView' | 'ViewContent' | 'Lead' | 'Contact', params?: Record<string, any>) {
  try {
    if (typeof window !== 'undefined') {
      window._fbqEvents = window._fbqEvents || [];
      window._fbqEvents.push({
        event: eventName,
        timestamp: new Date().toISOString(),
        params: params || {},
      });

      if (typeof window.fbq === 'function') {
        window.fbq('track', eventName, params);
      }
    }
  } catch (err) {
    console.debug('Pixel track error suppressed:', err);
  }
}

export function getUtmParameters(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: params.get('utm_source') || 'meta_ads',
    utm_medium: params.get('utm_medium') || 'cpc',
    utm_campaign: params.get('utm_campaign') || 'salon_growth_india',
    utm_content: params.get('utm_content') || 'dashboard_demo',
    utm_term: params.get('utm_term') || '',
    fbclid: params.get('fbclid') || '',
  };
}

export function buildWhatsAppLink(phoneNumber: string, salonName?: string, city?: string): string {
  const cleanPhone = (phoneNumber || '919820198201').replace(/\D/g, '');
  const salonText = salonName?.trim() ? salonName.trim() : '____';
  const cityText = city?.trim() ? city.trim() : '____';
  const message = `Hi, mujhe Salon OS software ka free live demo chahiye. Mere salon ka naam ${salonText} hai aur city ${cityText} hai.`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}
