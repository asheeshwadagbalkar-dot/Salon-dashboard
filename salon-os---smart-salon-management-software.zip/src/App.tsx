import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProblemSection } from './components/ProblemSection';
import { SolutionSection } from './components/SolutionSection';
import { VideoDemoSection } from './components/VideoDemoSection';
import { BeforeVsAfter } from './components/BeforeVsAfter';
import { HowItWorks } from './components/HowItWorks';
import { LeadCaptureForm } from './components/LeadCaptureForm';
import { FAQSection } from './components/FAQSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { WhatsAppStickyCTA } from './components/WhatsAppStickyCTA';
import { LegalModal } from './components/LegalModals';
import { trackMetaPixelEvent } from './utils/analytics';
import { ConfigData } from './types';

export default function App() {
  const [config, setConfig] = useState<ConfigData>({
    whatsappNumber: '919820198201',
    brandName: 'Salon OS',
    supportEmail: 'growth@salonos.in',
    demoSlotsToday: 4,
  });

  const [legalModalType, setLegalModalType] = useState<'privacy' | 'terms' | null>(null);

  useEffect(() => {
    // Fire initial PageView tracking event
    trackMetaPixelEvent('PageView', { page_title: 'Salon OS Landing' });

    // Fetch dynamic client config if available
    fetch('/api/config')
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error('Config endpoint unavailable');
      })
      .then((data) => {
        if (data && data.whatsappNumber) {
          setConfig((prev) => ({
            ...prev,
            whatsappNumber: data.whatsappNumber,
            supportEmail: data.supportEmail || prev.supportEmail,
          }));
        }
      })
      .catch((_err) => {
        // Fallback default is already set
      });
  }, []);

  const scrollToLeadForm = () => {
    const el = document.getElementById('lead-form');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      const nameInput = el.querySelector<HTMLInputElement>('input#fullName');
      if (nameInput) {
        setTimeout(() => nameInput.focus(), 600);
      }
    }
  };

  const scrollToVideoDemo = () => {
    const el = document.getElementById('video-demo');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToFeatures = () => {
    const el = document.getElementById('features');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col font-sans selection:bg-[#E11D48] selection:text-white">
      
      {/* Top Navigation */}
      <Header onBookDemoClick={scrollToLeadForm} />

      {/* Main Page Flow */}
      <main className="flex-1 pb-16 md:pb-0">
        {/* 1. Hero */}
        <Hero
          onBookDemoClick={scrollToLeadForm}
          onWatchDemoClick={scrollToVideoDemo}
        />

        {/* 2. Problem Section */}
        <ProblemSection onExploreSolutionClick={scrollToFeatures} />

        {/* 3. Solution / 10 Modules */}
        <SolutionSection onBookDemoClick={scrollToLeadForm} />

        {/* 4. Video Demo Section */}
        <VideoDemoSection onLiveDemoClick={scrollToLeadForm} />

        {/* 5. Before vs After */}
        <BeforeVsAfter />

        {/* 6. How It Works */}
        <HowItWorks onScheduleDemoClick={scrollToLeadForm} />

        {/* 7. Lead Capture Form */}
        <LeadCaptureForm
          onOpenPrivacyModal={() => setLegalModalType('privacy')}
          whatsappNumber={config.whatsappNumber}
        />

        {/* 8. FAQ */}
        <FAQSection />

        {/* 9. Final CTA */}
        <FinalCTA onBookDemoClick={scrollToLeadForm} />
      </main>

      {/* Footer */}
      <Footer
        whatsappNumber={config.whatsappNumber}
        supportEmail={config.supportEmail}
        onOpenPrivacyModal={() => setLegalModalType('privacy')}
        onOpenTermsModal={() => setLegalModalType('terms')}
      />

      {/* WhatsApp Sticky CTA Button (Mobile Bar + Desktop Floating Pill) */}
      <WhatsAppStickyCTA whatsappNumber={config.whatsappNumber} />

      {/* Privacy Policy & Terms Modal */}
      <LegalModal
        isOpen={legalModalType !== null}
        onClose={() => setLegalModalType(null)}
        type={legalModalType || 'privacy'}
      />

    </div>
  );
}
