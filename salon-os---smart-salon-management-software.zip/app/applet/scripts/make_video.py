import os
import subprocess

clip_files = [f"/tmp/salon_video_frames/clip_{s:02d}.mp4" for s in range(1, 11)]

# Build ffmpeg input arguments
inputs = []
for c in clip_files:
    inputs.extend(["-i", c])

# Concat filter for all 10 inputs
filter_str = "".join([f"[{i}:v]" for i in range(len(clip_files))]) + f"concat=n={len(clip_files)}:v=1:a=0[v]"

# 89s Audio
audio_path = "/tmp/salon_video_frames/audio.wav"
subprocess.run([
    "ffmpeg", "-y",
    "-f", "lavfi",
    "-i", "sine=frequency=520:beep_factor=4:sample_rate=44100",
    "-t", "89",
    "-af", "volume=0.08,lowpass=f=900",
    audio_path
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

output_video = "/app/applet/public/salon-os-demo.mp4"
cmd = [
    "ffmpeg", "-y",
    *inputs,
    "-i", audio_path,
    "-filter_complex", filter_str,
    "-map", "[v]",
    "-map", f"{len(clip_files)}:a",
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-c:a", "aac",
    "-b:a", "128k",
    "-movflags", "+faststart",
    output_video
]

res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res.returncode == 0:
    print("SUCCESS: Full 89s /app/applet/public/salon-os-demo.mp4 created!")
else:
    print("ERROR:", res.stderr.decode('utf-8'))
