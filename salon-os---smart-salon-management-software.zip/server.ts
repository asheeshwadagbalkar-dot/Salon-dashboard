import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Parse JSON bodies
app.use(express.json());

// Ensure data folder exists for persistence
const DATA_DIR = path.resolve(process.cwd(), 'data');
const LEADS_FILE = path.join(DATA_DIR, 'leads.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(LEADS_FILE)) {
  fs.writeFileSync(LEADS_FILE, JSON.stringify([], null, 2), 'utf-8');
}

function getStoredLeads(): any[] {
  try {
    const raw = fs.readFileSync(LEADS_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading leads file:', err);
    return [];
  }
}

function saveStoredLeads(leads: any[]): void {
  try {
    fs.writeFileSync(LEADS_FILE, JSON.stringify(leads, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing leads file:', err);
  }
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Salon OS Landing API',
  });
});

// Config endpoint for client-side configuration
app.get('/api/config', (_req: Request, res: Response) => {
  // Support custom phone from env or default Indian salon helpline
  const whatsappNumber = process.env.SALON_OS_WHATSAPP || process.env.WHATSAPP_NUMBER || '919820198201';
  res.json({
    whatsappNumber,
    brandName: 'Salon OS',
    supportEmail: 'growth@salonos.in',
    demoSlotsToday: 4,
  });
});

// Lead capture endpoint
app.post('/api/leads', async (req: Request, res: Response) => {
  try {
    const {
      fullName,
      whatsappNumber,
      salonName,
      city,
      salonType,
      staffCount,
      challenge,
      consent,
      honeypot,
      utm_source,
      utm_medium,
      utm_campaign,
      utm_content,
      utm_term,
      fbclid,
      variant,
    } = req.body;

    // Spam honeypot trap
    if (honeypot && honeypot.trim() !== '') {
      return res.status(400).json({
        success: false,
        error: 'Invalid submission detected.',
      });
    }

    // Required field validation
    if (!fullName || fullName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Kripya apna poora naam enter karein.',
      });
    }

    // Indian 10-digit phone normalization and validation
    const rawDigits = (whatsappNumber || '').replace(/\D/g, '');
    let cleanPhone = rawDigits;
    if (cleanPhone.length === 12 && cleanPhone.startsWith('91')) {
      cleanPhone = cleanPhone.slice(2);
    } else if (cleanPhone.length === 11 && cleanPhone.startsWith('0')) {
      cleanPhone = cleanPhone.slice(1);
    }

    const isValidIndianMobile = /^[6-9]\d{9}$/.test(cleanPhone);
    if (!isValidIndianMobile) {
      return res.status(400).json({
        success: false,
        error: 'Kripya ek valid 10-digit Indian WhatsApp number enter karein (e.g. 9820198201).',
      });
    }

    if (!salonName || salonName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Kripya apne salon ka naam enter karein.',
      });
    }

    if (!city || city.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Kripya apna city enter karein.',
      });
    }

    if (!consent) {
      return res.status(400).json({
        success: false,
        error: 'Kripya demo request ke liye WhatsApp/phone communication consent ko accept karein.',
      });
    }

    const leads = getStoredLeads();
    const now = new Date();

    // Duplicate check: within the last 12 hours with same phone
    const existingIndex = leads.findIndex(
      (l) => l.whatsappNumber === cleanPhone && (now.getTime() - new Date(l.createdAt).getTime()) < 12 * 60 * 60 * 1000
    );

    if (existingIndex !== -1) {
      const existing = leads[existingIndex];
      return res.json({
        success: true,
        isDuplicate: true,
        leadId: existing.id,
        message: 'Aapka demo request pehle se registered hai! Hamari team aapse 15-30 minute mein sampark karegi.',
        lead: {
          id: existing.id,
          fullName: existing.fullName,
          salonName: existing.salonName,
          city: existing.city,
        },
      });
    }

    const leadId = `LEAD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newLead = {
      id: leadId,
      fullName: fullName.trim(),
      whatsappNumber: cleanPhone,
      formattedPhone: `+91 ${cleanPhone.slice(0, 5)} ${cleanPhone.slice(5)}`,
      salonName: salonName.trim(),
      city: city.trim(),
      salonType: salonType || 'Unisex Salon',
      staffCount: staffCount || '1-3 staff',
      challenge: challenge || 'Appointments & Billing',
      consent: Boolean(consent),
      utm: {
        source: utm_source || 'meta_ads',
        medium: utm_medium || 'cpc',
        campaign: utm_campaign || 'salon_owners_india',
        content: utm_content || 'video_demo',
        term: utm_term || '',
        fbclid: fbclid || '',
      },
      variant: variant || 'v1_landing_hinglish',
      createdAt: now.toISOString(),
      status: 'pending_demo_call',
    };

    leads.unshift(newLead);
    saveStoredLeads(leads);

    // Forward to external webhook if configured in env
    const webhookUrl = process.env.CRM_WEBHOOK_URL || process.env.LEAD_WEBHOOK_URL;
    if (webhookUrl) {
      try {
        fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newLead),
        }).catch((err) => console.error('Webhook dispatch error:', err));
      } catch (err) {
        console.error('Webhook execution failed:', err);
      }
    }

    return res.json({
      success: true,
      leadId,
      message: 'Demo slot reserved successfully!',
      lead: {
        id: leadId,
        fullName: newLead.fullName,
        salonName: newLead.salonName,
        city: newLead.city,
      },
    });
  } catch (err: any) {
    console.error('Lead submission failure:', err);
    return res.status(500).json({
      success: false,
      error: 'Lead save karne mein dikkat aayi. Kripya punah prayas karein ya WhatsApp par direct message karein.',
    });
  }
});

// Admin / verification endpoint for checking captured leads
app.get('/api/leads', (_req: Request, res: Response) => {
  const leads = getStoredLeads();
  res.json({
    total: leads.length,
    leads: leads.slice(0, 30),
  });
});

async function startServer() {
  if (!isProduction) {
    // Mount Vite dev server middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    // Serve transformed index.html for all non-API GET requests
    app.use('*', async (req: Request, res: Response, next) => {
      if (req.originalUrl.startsWith('/api')) {
        return next();
      }
      try {
        const url = req.originalUrl;
        const indexPath = path.resolve(process.cwd(), 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    // Serve production static assets
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Salon OS landing app running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
