import os
import subprocess

os.makedirs('/app/applet/public', exist_ok=True)
os.makedirs('/tmp/salon_video_frames', exist_ok=True)

slides = [
    {
        "id": "01",
        "dur": 9,
        "title": "Salon OS — Smart Salon Management Dashboard",
        "tag": "ATTENTION SALON OWNERS",
        "sub": "Appointments · POS Billing · Staff Management · Customer CRM · Inventory · WhatsApp",
        "highlight": "Salon ka hisab-kitab, booking aur customers — ab sab ek smart dashboard par!",
        "accent": "#D946EF",
        "stats": [
            ("All-in-One", "Cloud System"),
            ("Fast", "10-Sec Billing"),
            ("Indian Salons", "Tailored"),
            ("Zero", "Double-Bookings")
        ]
    },
    {
        "id": "02",
        "dur": 11,
        "title": "01. Executive Overview Dashboard",
        "tag": "REAL-TIME SALON METRICS",
        "sub": "Daily Revenue, Active Stylists & Service Category Trends",
        "highlight": "Today's Revenue: Rs 5,240  |  Active Stylists: 4  |  Client Retention Rate: 82%",
        "accent": "#38BDF8",
        "stats": [
            ("Rs 5,240", "Today's Sales"),
            ("82%", "Retention Rate"),
            ("4 Stylists", "On Duty Today"),
            ("Hair & Skin", "Top Categories")
        ]
    },
    {
        "id": "03",
        "dur": 10,
        "title": "02. Appointments & Multi-Chair Calendar",
        "tag": "ZERO DOUBLE-BOOKINGS",
        "sub": "Kavita Reddy (Haircut) · Pooja Verma (Styling) · Aditi Sharma (Hydra-Facial)",
        "highlight": "Single digital calendar with instant chair allocation, stylist assignment and walk-in drawer.",
        "accent": "#EC4899",
        "stats": [
            ("Chair 1", "Kavita R. (Rs 850)"),
            ("Chair 2", "Pooja V. (Rs 850)"),
            ("Chair 3", "Aditi S. (Rs 2,199)"),
            ("Auto-Sync", "WhatsApp Alerts")
        ]
    },
    {
        "id": "04",
        "dur": 10,
        "title": "03. Live POS Terminal & Instant UPI QR",
        "tag": "10-SECOND GST BILLING",
        "sub": "Kavita Reddy: Signature Haircut Rs 850 + GST (18%) Rs 153 = Total Rs 1,003",
        "highlight": "Generate bill in 10 seconds. Customer scans dynamic UPI QR on screen. Print receipt or send to WhatsApp.",
        "accent": "#10B981",
        "stats": [
            ("Rs 1,003", "Total Amount Due"),
            ("Dynamic QR", "GPay / PhonePe / Paytm"),
            ("Print / PDF", "Thermal Receipts"),
            ("Reconciled", "Cash & UPI Drawer")
        ]
    },
    {
        "id": "05",
        "dur": 7,
        "title": "04. Services & Menu Packages Catalog",
        "tag": "SERVICES & PACKAGES",
        "sub": "Haircut Rs 850 · Keratin Rs 4,999 · Hydra-Facial Rs 2,199 · Grooming Rs 450 · Bridal Rs 8,500",
        "highlight": "Create custom rate cards, festive packages, and multi-session membership cards easily.",
        "accent": "#F59E0B",
        "stats": [
            ("Keratin", "Rs 4,999 (180m)"),
            ("Hydra-Facial", "Rs 2,199 (90m)"),
            ("Nail Art", "Rs 1,599 (90m)"),
            ("Bridal Makeup", "Rs 8,500 (120m)")
        ]
    },
    {
        "id": "06",
        "dur": 7,
        "title": "05. Staff Roster & Commission Engine",
        "tag": "STAFF & ROSTER",
        "sub": "Stylists: Bodan Karsli, Budry Sascha, Basian Karhsan, Jolidan Bardina",
        "highlight": "Track daily attendance, shift timings, service counts and transparent commissions without disputes.",
        "accent": "#A855F7",
        "stats": [
            ("Shift 1", "10:00 AM - 02:00 PM"),
            ("Shift 2", "02:00 PM - 06:00 PM"),
            ("Shift 3", "06:00 PM - 10:00 PM"),
            ("Automatic", "Commission Tiers")
        ]
    },
    {
        "id": "07",
        "dur": 7,
        "title": "06. Customer CRM & History Record",
        "tag": "CLIENT RETENTION CRM",
        "sub": "Kavita Reddy (+91 98450 12345) — 12 Visits · Rs 14,800 Spend · 30,000 Loyalty Points",
        "highlight": "Save hair dye shade formulas, allergy notes, package sessions and personal preferences for every client.",
        "accent": "#EC4899",
        "stats": [
            ("12 Visits", "Loyal Customer"),
            ("Rs 14,800", "Lifetime Spend"),
            ("Majirel 5.3", "Color Formula Note"),
            ("VIP Tag", "Auto-Identified")
        ]
    },
    {
        "id": "08",
        "dur": 8,
        "title": "07. WhatsApp Automation & Stock Tracking",
        "tag": "MESSAGING & INVENTORY",
        "sub": "Automated 2-hour appointment reminder + low inventory alert for hair chemical supplies",
        "highlight": "Keep clients updated automatically on WhatsApp and get alert before products run out of stock.",
        "accent": "#06B6D4",
        "stats": [
            ("2-Hr Reminder", "Delivered on WhatsApp"),
            ("Digital Invoice", "Auto-sent via link"),
            ("Low Stock", "L'Oreal 20 Vol (1 left)"),
            ("Zero Churn", "Repeat Reminders")
        ]
    },
    {
        "id": "09",
        "dur": 11,
        "title": "08. Business Reports & Financial Analytics",
        "tag": "CLEAR FINANCIAL VISIBILITY",
        "sub": "Total Revenue: Rs 39,740  |  Average Bill Size: Rs 1,420  |  UPI 68% vs Cash 22% vs Card 10%",
        "highlight": "Clear profit visibility, top profitable services, and complete daily collection summary at your fingertips.",
        "accent": "#10B981",
        "stats": [
            ("Rs 39,740", "Total Daily Revenue"),
            ("Rs 1,420", "Average Bill Size"),
            ("68% UPI", "Digital Payments"),
            ("GST Report", "1-Click Download")
        ]
    },
    {
        "id": "10",
        "dur": 14,
        "title": "Book Your 1-on-1 FREE Live Demo!",
        "tag": "ASHISH DIGITAL SOLUTIONS & SALON OS",
        "sub": "Message 'SALON DEMO' on WhatsApp or submit the form below",
        "highlight": "100% Free Personalized Walkthrough · Tailored for Your Salon's Chairs & Rate Card · No Credit Card Required",
        "accent": "#D946EF",
        "stats": [
            ("100% Free", "Zero Obligation"),
            ("15 Minutes", "Live Demo Call"),
            ("Indian Salons", "Dedicated Support"),
            ("Quick Setup", "Within 24 Hours")
        ]
    }
]

clip_files = []

for idx, s in enumerate(slides):
    svg_path = f"/tmp/salon_video_frames/slide_{s['id']}.svg"
    png_path = f"/tmp/salon_video_frames/slide_{s['id']}.png"
    clip_path = f"/tmp/salon_video_frames/clip_{s['id']}.mp4"
    
    stat_boxes = ""
    for b_idx, (val, lbl) in enumerate(s['stats']):
        bx = 80 + (b_idx * 280)
        stat_boxes += f"""
        <g transform="translate({bx}, 530)">
          <rect width="260" height="90" rx="16" fill="#131E3A" stroke="#25355A" stroke-width="1.5"/>
          <text x="20" y="42" fill="{s['accent']}" font-size="24" font-weight="bold" font-family="Liberation Sans, sans-serif">{val}</text>
          <text x="20" y="70" fill="#94A3B8" font-size="14" font-family="Liberation Sans, sans-serif">{lbl}</text>
        </g>
        """

    svg_content = f"""<svg width="1280" height="720" viewBox="0 0 1280 720" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg_grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0B132B"/>
      <stop offset="50%" stop-color="#0F172A"/>
      <stop offset="100%" stop-color="#070C1B"/>
    </linearGradient>
    <linearGradient id="glow_grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{s['accent']}" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#38BDF8" stop-opacity="0.1"/>
    </linearGradient>
  </defs>

  <!-- Background -->
  <rect width="1280" height="720" fill="url(#bg_grad)"/>

  <!-- Top Ambient Glow -->
  <ellipse cx="640" cy="80" rx="450" ry="120" fill="url(#glow_grad)" filter="blur(40px)"/>

  <!-- Header Bar -->
  <rect x="0" y="0" width="1280" height="70" fill="#090F21" stroke="#1E293B" stroke-width="1"/>
  <text x="60" y="44" fill="#FFFFFF" font-size="24" font-weight="bold" font-family="Liberation Sans, sans-serif">Salon <tspan fill="{s['accent']}">OS</tspan></text>
  <text x="180" y="44" fill="#64748B" font-size="14" font-family="Liberation Sans, sans-serif">| Official Product Walkthrough (01:29)</text>
  
  <rect x="1060" y="20" width="160" height="30" rx="8" fill="#1E293B"/>
  <text x="1140" y="40" fill="#38BDF8" font-size="13" font-family="Liberation Sans, sans-serif" text-anchor="middle">STEP {s['id']} OF 10</text>

  <!-- Main Content Card -->
  <rect x="60" y="100" width="1160" height="570" rx="24" fill="#0F172A" stroke="#1E293B" stroke-width="2"/>
  <rect x="60" y="100" width="1160" height="6" fill="{s['accent']}"/>

  <!-- Eyebrow Badge -->
  <rect x="90" y="130" width="340" height="32" rx="8" fill="#1E293B" stroke="{s['accent']}" stroke-width="1"/>
  <text x="105" y="151" fill="{s['accent']}" font-size="12" font-weight="bold" font-family="Liberation Sans, sans-serif">{s['tag']}</text>

  <!-- Title -->
  <text x="90" y="210" fill="#FFFFFF" font-size="34" font-weight="bold" font-family="Liberation Sans, sans-serif">{s['title']}</text>

  <!-- Subtitle -->
  <text x="90" y="255" fill="#38BDF8" font-size="18" font-weight="500" font-family="Liberation Sans, sans-serif">{s['sub']}</text>

  <!-- Feature Description Box -->
  <rect x="90" y="290" width="1100" height="200" rx="16" fill="#070C1B" stroke="#1E293B" stroke-width="1.5"/>
  
  <circle cx="125" cy="330" r="16" fill="{s['accent']}" fill-opacity="0.2"/>
  <text x="125" y="336" fill="{s['accent']}" font-size="16" font-weight="bold" text-anchor="middle" font-family="Liberation Sans, sans-serif">&#10003;</text>
  
  <text x="160" y="336" fill="#F8FAFC" font-size="20" font-weight="bold" font-family="Liberation Sans, sans-serif">{s['highlight'][:75]}</text>
  <text x="160" y="375" fill="#94A3B8" font-size="16" font-family="Liberation Sans, sans-serif">{s['highlight'][75:170]}</text>
  
  <line x1="120" y1="410" x2="1160" y2="410" stroke="#1E293B" stroke-width="1"/>
  <text x="125" y="445" fill="#E2E8F0" font-size="15" font-family="Liberation Sans, sans-serif">Features: Instant Sync &#8226; Indian Rupee (INR) POS &#8226; WhatsApp Business Ready &#8226; Zero Setup Friction</text>

  <!-- 4 Dynamic Stat Cards -->
  {stat_boxes}

</svg>"""

    with open(svg_path, 'w') as f:
        f.write(svg_content)
    
    # Convert SVG to PNG
    subprocess.run(["ffmpeg", "-y", "-i", svg_path, png_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Generate MP4 subclip with exact duration
    subprocess.run([
        "ffmpeg", "-y",
        "-loop", "1", "-i", png_path,
        "-c:v", "libx264", "-t", str(s['dur']),
        "-pix_fmt", "yuv420p", "-r", "25",
        clip_path
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    clip_files.append(clip_path)

# Concat all subclips into one video
concat_txt = "/tmp/salon_video_frames/concat_clips.txt"
with open(concat_txt, 'w') as f:
    for c in clip_files:
        f.write(f"file '{c}'\n")

video_raw = "/tmp/salon_video_frames/combined_video.mp4"
subprocess.run([
    "ffmpeg", "-y",
    "-f", "concat", "-safe", "0", "-i", concat_txt,
    "-c", "copy",
    video_raw
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Audio track: 89 seconds
audio_path = "/tmp/salon_video_frames/audio.wav"
subprocess.run([
    "ffmpeg", "-y",
    "-f", "lavfi",
    "-i", "sine=frequency=520:beep_factor=4:sample_rate=44100",
    "-t", "89",
    "-af", "volume=0.08,lowpass=f=900",
    audio_path
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Final video mux
output_video = "/app/applet/public/salon-os-demo.mp4"
cmd = [
    "ffmpeg", "-y",
    "-i", video_raw,
    "-i", audio_path,
    "-c:v", "copy",
    "-c:a", "aac",
    "-b:a", "128k",
    "-shortest",
    "-movflags", "+faststart",
    output_video
]

res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res.returncode == 0:
    print("SUCCESS: 89-second /app/applet/public/salon-os-demo.mp4 created!")
else:
    print("FFMPEG ERROR:", res.stderr.decode('utf-8'))
